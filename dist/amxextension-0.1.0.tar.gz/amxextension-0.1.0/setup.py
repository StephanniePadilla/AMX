# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['amx_ext']

package_data = \
{'': ['*']}

install_requires = \
['connect-extension-runner>=24.0.0,<25.0.0']

entry_points = \
{'connect.eaas.ext': ['extension = amx_ext.extension:AmxextensionExtension']}

setup_kwargs = {
    'name': 'amxextension',
    'version': '0.1.0',
    'description': 'Extension para el modulo de DevOps de AMX',
    'long_description': '# Welcome to AMXextension !\n\n\nExtension para el modulo de DevOps de AMX\n\n\n\n## License\n\n**AMXextension** is licensed under the *Apache Software License 2.0* license.\n\n',
    'author': 'Steph de Education',
    'author_email': None,
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
